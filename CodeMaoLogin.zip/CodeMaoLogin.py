#Author:Fox-Awa组织 desc:本Python是对编程猫登录接口的一个封装。
import requests,json;
class CodeMaoLogin:
    def login(u,p):#auth里面的东西是最重要的说！
        r=requests.post("https://api.codemao.cn/tiger/v3/web/accounts/login",str({"username":u,"password":p,"pid":"65edCTyg"}),headers={"Content-Type":"application/json"});
        if r.status_code==403:return {};else:return json.loads(r.text);#不是吧这么简单！?
#相关API链接：（需要auth里的bearer密钥传cookie authorization，示例cookie:authorization=eyxxxxxxxx...）
#https://api.codemao.cn/api/user/info (POST,need auth)获得昵称和真名。
#https://api.codemao.cn/api/v2/pc/lesson/user/info (POST,need auth)获得编程猫课上真名。
#https://api.codemao.cn/api/work/list (POST,need auth)获得所有作品
#https://api.codemao.cn/api/user/attention/[user_id，可在获得昵称和真名的API取到，data>>userInfo>>id] (POST,need auth)关注/取关
#https://api.codemao.cn/web/works/[作品id] (GET)得到作品基本信息
#更多API请自行抓包。这个API精简，但有用。
#提示一下:DevTools>>Network，过滤器选择XHR，可以看到编程猫比较多的API。（忽略GET请求可以拿到一些需要身份验证的请求。开着Network进行一些操作（sort by>>选中waterfall），然后进行操作后选中最新的XHR请求，就可看到API链接了。需要自己分析参数及cookie哦！）
